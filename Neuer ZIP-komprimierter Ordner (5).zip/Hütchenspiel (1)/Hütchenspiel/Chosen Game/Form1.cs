﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chosen_Game
{
    public partial class Form2 : Form
    {
        public Form2 thisForm;
        static int coins = 100;
       static Random rnd = new Random();
        static int ball = rnd.Next(1, 4);
    
        public Form2()
        {
            InitializeComponent();
         
            textBox1.Text = $"{coins} coins";
            ball = rnd.Next(1, 4);
            if (coins == 0)
            {
                MessageBox.Show("The king has given you a gift.");
                coins = coins + 50;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

            string money = moneyAmount.Text;
        }

        private void userBet_Click(object sender, EventArgs e)
        {
            button4.Visible = true;
            moneyAmount.Visible = true;
            MessageBox.Show( "How much do you want to bet? ");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ball == 1)
            {
                coins = coins * 2;
                textBox1.Text = $"{coins} coins";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button5.Enabled = false;
                userBet.Enabled = false;
                button7.Visible = true;

            }
            else if (ball != 3)
            {
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button5.Enabled = false;
                userBet.Enabled = false;
                coins = coins / 2;
                button8.Visible = true;

            }
            button9.Visible = true;
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ball == 2)
            {
                coins = coins * 2;
                textBox1.Text = $"{coins} coins";
               
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button5.Enabled = false;
                userBet.Enabled = false;
                button7.Visible = true;

            }
            else if (ball != 3)
            {
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button5.Enabled = false;
                userBet.Enabled = false;
                coins = coins / 2;
                button8.Visible = true;
            }
            button9.Visible = true;
        

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ball == 3)
            {
                coins = coins * 2;
                textBox1.Text = $"{coins} coins";
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button5.Enabled = false;
                userBet.Enabled = false;
                button7.Visible = true;
            }
            else if (ball != 3)
            {
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button5.Enabled = false;
                userBet.Enabled = false;
                coins = coins / 2;
                button8.Visible = true;

            }
            button9.Visible = true;
          
        }

        private void button4_Click(object sender, EventArgs e)
        {
            bool a = true;   
            while (a)
            {
                try
                {
                    uint bet = (uint)Convert.ToUInt32(userBet.Text);
                    if (bet > coins)
                    {
                        throw new Exception();
                    }
                }
                catch (Exception)
                {
                    userBet.Text = "Wrong input";
                    userBet.Text = "";
                    break;

                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            thisForm = new Form2();
            thisForm.Show();
            this.Hide();
        }
       private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form2 thisForm = new Form2();
            thisForm.Close();
        }
    }
}
